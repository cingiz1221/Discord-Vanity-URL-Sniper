kurulum için,,,
for installation support
لدعم التثبيت..

https://www.youtube.com/@zonsxd
